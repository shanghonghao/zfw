'use strict';

/**
 * @ngdoc function
 * @name zfwApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the zfwApp
 */
angular.module('zfwApp').controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
