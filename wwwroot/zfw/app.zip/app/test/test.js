obj.data.beans[0].menuType
obj.data.beans[0].menuName